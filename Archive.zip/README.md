# RAG vs GraphRAG

This notebook proposes the benefits of using a graph database for GraphRAG instead of the limited in-memory RAG approach.

To get started, load the contents of this repo into an ArangoGraph Jupyter notebook and be sure to update with your own OpenAI key.

## Suggestion

You can upload the files manually or with whatever method you choose.

One suggestion would be to upload a single zip and uncompress it.

1. Compress the contents of this repository (name it Archive.zip)
2. Upload the Archive.zip and unzip.py
2. Open a terminal and run `python unzip.py` in the same directory